from .nucleo import Idiomas
